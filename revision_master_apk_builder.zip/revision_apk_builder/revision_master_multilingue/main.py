# -*- coding: utf-8 -*-
"""Revision Master — prototype d'apprentissage multilingue gamifié."""
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from kivy.core.window import Window
from kivy.metrics import dp

LANGS = {
    "Français": {
        "app":"Revision Master", "choose_lang":"Choisis la langue", "choose_level":"Choisis ton niveau",
        "choose_subject":"Choisis une matière", "choose_lesson":"Choisis une leçon", "continue":"CONTINUER",
        "back":"← Retour", "quit":"Quitter", "next":"SUIVANT", "result":"RÉSULTAT",
        "correct":"Bonne réponse ! +10 XP", "wrong":"Pas tout à fait.", "finished":"Leçon terminée !",
        "score":"Score", "xp":"XP", "hearts":"Cœurs", "start":"COMMENCER", "home":"Accueil",
        "levels":{"Primaire":"Primaire","Collège":"Collège","Tronc commun":"Tronc commun","1re Bac":"1re Bac","2e Bac":"2e Bac"},
        "subjects":{"Mathématiques":"Mathématiques","Français":"Français","Sciences":"Sciences","Physique-Chimie":"Physique-Chimie","SVT":"SVT","Philosophie":"Philosophie"},
        "questions":[
            ("Mathématiques", "Combien font 7 + 5 ?", ["10","12","13"], 1, "7 + 5 = 12."),
            ("Français", "Quel est le pluriel de « cheval » ?", ["chevals","chevaux","chevales"], 1, "On écrit « chevaux »."),
            ("Philosophie", "Qui a écrit « Je pense, donc je suis » ?", ["Platon","Descartes","Kant"], 1, "Cette formule est associée à René Descartes."),
        ],
    },
    "العربية": {
        "app":"مراجعة بلس", "choose_lang":"اختر اللغة", "choose_level":"اختر المستوى الدراسي",
        "choose_subject":"اختر المادة", "choose_lesson":"اختر الدرس", "continue":"متابعة",
        "back":"← رجوع", "quit":"خروج", "next":"التالي", "result":"النتيجة",
        "correct":"إجابة صحيحة! +10 نقاط", "wrong":"ليس تماماً.", "finished":"انتهى الدرس!",
        "score":"النتيجة", "xp":"نقاط", "hearts":"القلوب", "start":"ابدأ", "home":"الرئيسية",
        "levels":{"Primaire":"الابتدائي","Collège":"الإعدادي","Tronc commun":"الجذع المشترك","1re Bac":"الأولى باك","2e Bac":"الثانية باك"},
        "subjects":{"Mathématiques":"الرياضيات","Français":"الفرنسية","Sciences":"العلوم","Physique-Chimie":"الفيزياء والكيمياء","SVT":"علوم الحياة والأرض","Philosophie":"الفلسفة"},
        "questions":[
            ("الرياضيات", "كم يساوي 7 + 5؟", ["10","12","13"], 1, "7 + 5 = 12."),
            ("الفرنسية", "ما جمع كلمة cheval بالفرنسية؟", ["chevals","chevaux","chevales"], 1, "الجمع الصحيح هو chevaux."),
            ("الفلسفة", "من صاحب مقولة «أنا أفكر، إذن أنا موجود»؟", ["أفلاطون","ديكارت","كانط"], 1, "ترتبط هذه المقولة بالفيلسوف رينيه ديكارت."),
        ],
    },
    "English": {
        "app":"Revision Master", "choose_lang":"Choose a language", "choose_level":"Choose your school level",
        "choose_subject":"Choose a subject", "choose_lesson":"Choose a lesson", "continue":"CONTINUE",
        "back":"← Back", "quit":"Quit", "next":"NEXT", "result":"RESULT",
        "correct":"Correct! +10 XP", "wrong":"Not quite.", "finished":"Lesson complete!",
        "score":"Score", "xp":"XP", "hearts":"Hearts", "start":"START", "home":"Home",
        "levels":{"Primaire":"Primary school","Collège":"Middle school","Tronc commun":"Common core","1re Bac":"First Bac year","2e Bac":"Second Bac year"},
        "subjects":{"Mathématiques":"Mathematics","Français":"French","Sciences":"Science","Physique-Chimie":"Physics & Chemistry","SVT":"Life & Earth Science","Philosophie":"Philosophy"},
        "questions":[
            ("Mathematics", "What is 7 + 5?", ["10","12","13"], 1, "7 + 5 = 12."),
            ("French", "What is the plural of « cheval »?", ["chevals","chevaux","chevales"], 1, "The correct plural is « chevaux »."),
            ("Philosophy", "Who is associated with “I think, therefore I am”?", ["Plato","Descartes","Kant"], 1, "The phrase is associated with René Descartes."),
        ],
    },
    "Español": {
        "app":"Revision Master", "choose_lang":"Elige un idioma", "choose_level":"Elige tu nivel escolar",
        "choose_subject":"Elige una materia", "choose_lesson":"Elige una lección", "continue":"CONTINUAR",
        "back":"← Volver", "quit":"Salir", "next":"SIGUIENTE", "result":"RESULTADO",
        "correct":"¡Correcto! +10 XP", "wrong":"No exactamente.", "finished":"¡Lección terminada!",
        "score":"Puntuación", "xp":"XP", "hearts":"Vidas", "start":"EMPEZAR", "home":"Inicio",
        "levels":{"Primaire":"Primaria","Collège":"Secundaria","Tronc commun":"Tronco común","1re Bac":"1.º Bachillerato","2e Bac":"2.º Bachillerato"},
        "subjects":{"Mathématiques":"Matemáticas","Français":"Francés","Sciences":"Ciencias","Physique-Chimie":"Física y química","SVT":"Biología y geología","Philosophie":"Filosofía"},
        "questions":[
            ("Matemáticas", "¿Cuánto es 7 + 5?", ["10","12","13"], 1, "7 + 5 = 12."),
            ("Francés", "¿Cuál es el plural de « cheval »?", ["chevals","chevaux","chevales"], 1, "El plural correcto es « chevaux »."),
            ("Filosofía", "¿Quién está asociado con « Pienso, luego existo »?", ["Platón","Descartes","Kant"], 1, "La frase se asocia con René Descartes."),
        ],
    },
    "Deutsch": {
        "app":"Revision Master", "choose_lang":"Sprache auswählen", "choose_level":"Schulstufe auswählen",
        "choose_subject":"Fach auswählen", "choose_lesson":"Lektion auswählen", "continue":"WEITER",
        "back":"← Zurück", "quit":"Beenden", "next":"WEITER", "result":"ERGEBNIS",
        "correct":"Richtig! +10 XP", "wrong":"Nicht ganz.", "finished":"Lektion abgeschlossen!",
        "score":"Punktzahl", "xp":"XP", "hearts":"Herzen", "start":"START", "home":"Startseite",
        "levels":{"Primaire":"Grundschule","Collège":"Mittelschule","Tronc commun":"Gemeinsamer Kern","1re Bac":"1. Bac-Jahr","2e Bac":"2. Bac-Jahr"},
        "subjects":{"Mathématiques":"Mathematik","Français":"Französisch","Sciences":"Naturwissenschaften","Physique-Chimie":"Physik und Chemie","SVT":"Biologie und Geologie","Philosophie":"Philosophie"},
        "questions":[
            ("Mathematik", "Wie viel ist 7 + 5?", ["10","12","13"], 1, "7 + 5 = 12."),
            ("Französisch", "Was ist der Plural von « cheval »?", ["chevals","chevaux","chevales"], 1, "Der richtige Plural ist « chevaux »."),
            ("Philosophie", "Wer ist mit „Ich denke, also bin ich“ verbunden?", ["Platon","Descartes","Kant"], 1, "Der Satz wird René Descartes zugeschrieben."),
        ],
    },
    "Português": {
        "app":"Revision Master", "choose_lang":"Escolhe um idioma", "choose_level":"Escolhe o nível escolar",
        "choose_subject":"Escolhe uma disciplina", "choose_lesson":"Escolhe uma lição", "continue":"CONTINUAR",
        "back":"← Voltar", "quit":"Sair", "next":"SEGUINTE", "result":"RESULTADO",
        "correct":"Correto! +10 XP", "wrong":"Não exatamente.", "finished":"Lição concluída!",
        "score":"Pontuação", "xp":"XP", "hearts":"Vidas", "start":"COMEÇAR", "home":"Início",
        "levels":{"Primaire":"Primária","Collège":"Ensino básico","Tronc commun":"Núcleo comum","1re Bac":"1.º ano do Bac","2e Bac":"2.º ano do Bac"},
        "subjects":{"Mathématiques":"Matemática","Français":"Francês","Sciences":"Ciências","Physique-Chimie":"Física e Química","SVT":"Biologia e Geologia","Philosophie":"Filosofia"},
        "questions":[
            ("Matemática", "Quanto é 7 + 5?", ["10","12","13"], 1, "7 + 5 = 12."),
            ("Francês", "Qual é o plural de « cheval »?", ["chevals","chevaux","chevales"], 1, "O plural correto é « chevaux »."),
            ("Filosofia", "Quem está associado a « Penso, logo existo »?", ["Platão","Descartes","Kant"], 1, "A frase está associada a René Descartes."),
        ],
    },
}

LEVEL_KEYS = ["Primaire", "Collège", "Tronc commun", "1re Bac", "2e Bac"]
SUBJECT_KEYS = ["Mathématiques", "Français", "Sciences", "Physique-Chimie", "SVT", "Philosophie"]
BG=(0.96,0.98,0.95,1); DARK=(0.12,0.20,0.17,1); GREEN=(0.22,0.68,0.34,1)
GD=(0.13,0.48,0.25,1); PALE=(0.88,0.96,0.88,1); RED=(0.88,0.27,0.29,1); GREY=(0.40,0.47,0.43,1); WHITE=(1,1,1,1)

def lbl(text="", size=18, color=DARK, bold=False, **kw):
    return Label(text=text, font_size=f"{size}sp", color=color, bold=bold,
                 halign="center", valign="middle", **kw)

def btn(text, bg=GREEN, fg=WHITE, height=dp(52), size=16):
    return Button(text=text, size_hint_y=None, height=height, font_size=f"{size}sp", bold=True,
                  color=fg, background_normal="", background_down="", background_color=bg)

class RevisionMaster(App):
    def build(self):
        self.language="Français"; self.level="Primaire"; self.subject="Mathématiques"
        self.xp=0; self.hearts=5; self.q_idx=0; self.score=0; self.answered=False
        Window.clearcolor=BG
        self.root_box=BoxLayout(orientation="vertical",padding=dp(14),spacing=dp(9))
        self.home(); return self.root_box

    @property
    def T(self): return LANGS[self.language]

    def reset(self): self.root_box.clear_widgets()

    def header(self):
        row=BoxLayout(size_hint_y=None,height=dp(42),spacing=dp(5))
        row.add_widget(lbl("🟢",21,GREEN,True))
        row.add_widget(lbl(self.T["app"],19,DARK,True))
        row.add_widget(lbl(f"⭐ {self.xp} {self.T['xp']}",14,GD,True))
        self.root_box.add_widget(row)

    def home(self):
        self.reset(); self.header()
        self.root_box.add_widget(lbl(self.T["choose_lang"],22,GD,True,size_hint_y=None,height=dp(42)))
        sp=Spinner(text=self.language,values=list(LANGS.keys()),size_hint_y=None,height=dp(48))
        sp.bind(text=self.change_language); self.root_box.add_widget(sp)
        self.root_box.add_widget(lbl(self.T["choose_level"],22,GD,True,size_hint_y=None,height=dp(45)))
        for key in LEVEL_KEYS:
            b=btn(self.T["levels"][key],PALE,DARK,dp(48),16)
            b.bind(on_release=lambda _b,k=key:self.subjects(k)); self.root_box.add_widget(b)
        self.root_box.add_widget(Widget())
        self.root_box.add_widget(lbl("🌍 6 langues d'interface • QCM de démonstration",13,GREY))
    def change_language(self, spinner, value):
        self.language=value; self.home()

    def subjects(self, level):
        self.level=level; self.reset(); self.header()
        self.root_box.add_widget(lbl(self.T["choose_subject"],23,GD,True,size_hint_y=None,height=dp(48)))
        scroll=ScrollView(); col=BoxLayout(orientation="vertical",spacing=dp(8),size_hint_y=None)
        col.bind(minimum_height=col.setter("height"))
        for key in SUBJECT_KEYS:
            b=btn(self.T["subjects"][key],PALE,DARK,dp(52),17)
            b.bind(on_release=lambda _b,s=key:self.start_quiz(s))
            col.add_widget(b)
        scroll.add_widget(col); self.root_box.add_widget(scroll)
        back=btn(self.T["back"],(0.84,0.91,0.84,1),DARK,dp(44),14)
        back.bind(on_release=lambda *_:self.home()); self.root_box.add_widget(back)

    def start_quiz(self, subject):
        self.subject=subject; self.q_idx=0; self.score=0; self.hearts=5; self.show_question()

    def show_question(self):
        self.answered=False; self.reset(); self.header()
        q=self.T["questions"][self.q_idx]
        self.root_box.add_widget(lbl(f"{self.T['levels'][self.level]} • {q[0]}",14,GREY,True,
                                     size_hint_y=None,height=dp(30)))
        self.root_box.add_widget(lbl(f"{self.q_idx+1}/3    {'❤️ '*self.hearts}",15,RED,True,
                                     size_hint_y=None,height=dp(32)))
        self.root_box.add_widget(lbl(q[1],22,DARK,True))
        self.answer_buttons=[]
        for choice in q[2]:
            b=btn(choice,PALE,DARK,dp(58),18)
            b.bind(on_release=lambda _b,a=choice:self.answer(a))
            self.answer_buttons.append(b); self.root_box.add_widget(b)
        self.feedback=lbl("",14,GD,True,size_hint_y=None,height=dp(56)); self.root_box.add_widget(self.feedback)
        self.root_box.add_widget(Widget())
        row=BoxLayout(size_hint_y=None,height=dp(50),spacing=dp(8))
        back=btn(self.T["quit"],(0.84,0.91,0.84,1),DARK,dp(48),14)
        back.bind(on_release=lambda *_:self.subjects(self.level))
        self.next_btn=btn(self.T["next"],GD,WHITE,dp(48),14); self.next_btn.disabled=True
        self.next_btn.bind(on_release=self.next_question)
        row.add_widget(back); row.add_widget(self.next_btn); self.root_box.add_widget(row)

    def answer(self, answer):
        if self.answered:return
        self.answered=True; q=self.T["questions"][self.q_idx]
        for b in self.answer_buttons:b.disabled=True
        if answer==q[2][q[3]]:
            self.score+=1; self.xp+=10; self.feedback.text=self.T["correct"]+"\n"+q[4]; self.feedback.color=GD
        else:
            self.hearts=max(0,self.hearts-1); self.feedback.text=self.T["wrong"]+"\n"+q[4]; self.feedback.color=RED
        self.next_btn.disabled=False
        if self.q_idx==2:self.next_btn.text=self.T["result"]

    def next_question(self,*_):
        if self.q_idx<2:self.q_idx+=1; self.show_question()
        else:self.result()

    def result(self):
        self.reset(); self.header()
        self.root_box.add_widget(Widget())
        self.root_box.add_widget(lbl("🏆 "+self.T["finished"],26,GD,True))
        self.root_box.add_widget(lbl(f"{self.T['score']} : {self.score}/3",22,DARK,True))
        self.root_box.add_widget(lbl(f"+{self.score*10} {self.T['xp']}",21,GREEN,True))
        self.root_box.add_widget(Widget())
        again=btn(self.T["start"],GD); again.bind(on_release=lambda *_:self.start_quiz(self.subject))
        self.root_box.add_widget(again)
        home=btn(self.T["home"],(0.84,0.91,0.84,1),DARK); home.bind(on_release=lambda *_:self.home())
        self.root_box.add_widget(home)

if __name__=="__main__": RevisionMaster().run()
