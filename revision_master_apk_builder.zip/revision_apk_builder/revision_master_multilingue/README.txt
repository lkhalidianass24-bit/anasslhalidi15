REVISION MASTER MULTILINGUE

Langues d'interface incluses dans cette démo :
- العربية
- Français
- English
- Español
- Deutsch
- Português

Le menu permet de changer la langue de l'interface. Le contenu pédagogique intégré
est limité à quelques QCM d'exemple traduits : ce n'est pas encore un cours complet
dans toutes les langues, et toutes les traductions doivent être vérifiées avant usage scolaire.

Niveaux proposés : primaire, collège, tronc commun, 1re Bac, 2e Bac.
Le prototype utilise Kivy et Buildozer.

Ce ZIP est le code source, pas un APK prêt à installer.
Pour construire sur Linux/Google Colab, installer les dépendances Buildozer puis exécuter :
    buildozer android debug
L'APK généré se trouvera dans le dossier bin/.
