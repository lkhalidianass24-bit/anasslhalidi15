REVISION MASTER — BUILD APK ON WINDOWS 10 USING GITHUB ACTIONS

Important: this ZIP contains source code and an automated build recipe, not an already-built APK. The APK must be compiled online because Android build tools are not installed in this chat environment.

Steps:
1. On your Windows 10 PC, open https://github.com and sign in (or create an account with a parent/guardian if needed).
2. Create a new repository. Name it revision-master-apk. Set it to Private if you prefer. Do not add a README/license/gitignore during creation.
3. Extract this ZIP on your PC.
4. Upload the folder contents to the repository, keeping these paths:
   - .github/workflows/build-apk.yml
   - revision_master_multilingue/main.py
   - revision_master_multilingue/buildozer.spec
   - revision_master_multilingue/README.txt
   Use Add file > Upload files on GitHub. Drag the .github folder and revision_master_multilingue folder into the upload area. Commit the upload to main.
5. Open the repository's Actions tab. Choose “Build Revision Master APK”. If prompted, click “Enable workflow”, then “Run workflow” > “Run workflow”.
6. Wait for the workflow to finish with a green check mark.
7. Open the completed workflow run, scroll to Artifacts, and download “revision-master-apk”. It downloads as a ZIP. Extract it to find the .apk file.
8. To install on Android, transfer the APK to the phone and open it. Android may ask you to allow installation from that source; only proceed if you trust the APK you built yourself.

Notes:
- The first build can take several minutes and may fail if Android/Buildozer dependencies change. If it fails, open the failed run and share the last red error lines for troubleshooting.
- This is a prototype with six interface languages and a few example quiz questions, not a complete curriculum for every grade/language.
- No signing key is configured; this produces a debug APK for testing, not a Play Store release build.
